import { error } from "console"

export const api = {
    
    base : '/',

    
    get: async(param) => {
        const respuesta = await fetch(`${api.base}/${param}`)

        if (!respuesta.ok){
            throw new error('UPS! Error al hacer la peticion GET en el json')
        }

        return respuesta.json()
    
    },

    
    post: async(param) => {
        try {
            const respuesta = await fetch(`${base}/${param}`,{
                method : 'POST',
                header : { 'Content-Type' : 'application/json'},
                body : JSON.stringify(data)
        })            
        } catch (error) {
            console.error('Error al hacer la peticon POST en el json')
            throw (error)
        }

    },


    put: async(param) => {
        try {
            const respuesta = await fetch(`${base}/${param}`, {
                method : 'PUT',
                headers : {'Content-Type' : 'application/json'},
                body : JSON.stringify(data)
            })
        } catch (error) {
            console.error('Error al hacer la peticion PUT en el json')
            throw (error)
        }
    },
        
    
    del: async(param) => {
        const respuesta = await fetch(`${base}/${param}`, {
            method : 'DELETE'
        })

        if(respuesta.ok){
            throw new error('Error al hacer el metodo DELETE en el json')   
        }
    }
}